import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class SucasaHomePageTest {
    private WebDriver driver;
    private SucasaHomePage homePage;

    @BeforeMethod
    public void setUp() {
        // Set up WebDriver using WebDriverManager
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        homePage = new SucasaHomePage(driver);
    }

    @Test(priority = 1)
    public void verifySucasaStandardSectionText() {
        homePage.navigateToLink();
        homePage.goToSucasaStandardSection();

        // Verify the text in the Sucasa Standard section
        String sectionText = homePage.getSucasaStandardSectionText();
        Assert.assertTrue(sectionText.contains("Work From Anywhere"));
        Assert.assertTrue(sectionText.contains("Transparent Pricing"));
        Assert.assertTrue(sectionText.contains("Premium Properties"));
    }

    @Test(priority = 2)
    public void verifyWorkFromAnywhereSection() {
        homePage.navigateToLink();
        WorkFromAnywhereSectionPage workFromAnywherePage = homePage.goToWorkFromAnywhereSection();
        workFromAnywherePage.clickFindStaysButton();

        // Verify the page URL
        String expectedURL = "https://saucasa.zaptatech.com/index?#featured";
        Assert.assertEquals(driver.getCurrentUrl(), expectedURL);

        // Take a screenshot of the page
        String screenshotName = "FIRST_" + getCurrentTimestamp();
        workFromAnywherePage.takeScreenshot(screenshotName);
    }

    @AfterMethod
    public void tearDown() {
        // Quit the WebDriver
        driver.quit();
    }



    private String getCurrentTimestamp() {
        LocalTime currentTime = LocalTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH-mm-ss");
        return currentTime.format(formatter);
    }

}
