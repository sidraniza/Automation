import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;

public class WorkFromAnywhereSectionPage {
    private WebDriver driver;

    @FindBy(css = "a[href=\"https://saucasa.zaptatech.com/index?#featured\"]")
    private WebElement findStaysButton;

    public WorkFromAnywhereSectionPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickFindStaysButton() {
        driver.get(findStaysButton.getAttribute("href"));

    }

    public void takeScreenshot(String fileName) {
        try {
            // Capture screenshot as file
            File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

            // Define the destination file path with the provided file name and timestamp
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH-mm-ss"));
            String destinationFilePath = Paths.get("screenshots", fileName + "_" + timestamp + ".png").toString();

            // Save the screenshot to the destination file
            FileHandler.copy(screenshotFile, new File(destinationFilePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
