import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SucasaHomePage {
    private WebDriver driver;

    @FindBy(css = "div[class=\"container standard\"]")
    private WebElement link;

    @FindBy(css = "div[class=\"container standard\"]")
    private WebElement sucasaStandardSection;

    public SucasaHomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void navigateToLink() {
        driver.get("https://saucasa.zaptatech.com/");
    }

    public void goToSucasaStandardSection() {
        // Scroll or perform any necessary action to go to the Sucasa Standard section
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", link);

    }

    public String getSucasaStandardSectionText() {
        return sucasaStandardSection.getText();
    }

    public WorkFromAnywhereSectionPage goToWorkFromAnywhereSection() {
        // Perform necessary actions to go to the "Work From Anywhere" section
        // For example, click on a link or button that leads to the section

        // After navigating to the section, return an instance of the WorkFromAnywhereSectionPage
        return new WorkFromAnywhereSectionPage(driver);
    }
}
